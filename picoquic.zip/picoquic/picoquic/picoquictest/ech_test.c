/*
* Author: Christian Huitema
* Copyright (c) 2025, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "picoquic_internal.h"
#include "picoquic_utils.h"
#include "picosocks.h"
#include "tls_api.h"
#include "picoquictest_internal.h"
#ifdef _WINDOWS
#include "wincompat.h"
#pragma warning(disable:4204)
#endif
#include <picotls.h>
#ifdef _WINDOWS
#include <picotls\pembase64.h>
#include <picotls\minicrypto.h>
#else
#include <picotls/pembase64.h>
#include <picotls/minicrypto.h>
#endif
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "picoquictest.h"
typedef const struct st_ptls_cipher_suite_t ptls_cipher_suite_t;
#include "picoquic_crypto_provider_api.h"
#include "autoqlog.h"
#include "picoquic_logger.h"

 /* ech_config_test:
 * Create an ech configuration list, i.e., the content of an HTTPS "ech=" parameter.
  */
#define ECH_CONFIG_FILE_TXT "ech_config.txt"

int picoquic_ech_read_config(ptls_buffer_t* config, char const* file_name);
int picoquic_ech_create_config_from_public_key(uint8_t** config, size_t* config_len, char const* public_key_file, char const* public_name);
int picoquic_ech_create_config_from_private_key(uint8_t** config, size_t* config_len, char const* private_key_file, char const* public_name);
int picoquic_ech_save_config(uint8_t* config, size_t config_len, char const* file_name);

int ech_test_check_buf(uint8_t* config, size_t config_len, char const* ref_file_name)
{
    int ret = 0;
    char test_ref_file[512];

    ret = picoquic_get_input_path(test_ref_file, sizeof(test_ref_file), picoquic_solution_dir,
        ref_file_name);

    if (ret != 0) {
        DBG_PRINTF("Cannot find <%s> file in <%s>, err: %d (0x%x)", ref_file_name, picoquic_solution_dir, ret, ret);
    }
    else {
        ptls_buffer_t config_buffer;
        ptls_buffer_init(&config_buffer, "", 0);
        ret = picoquic_ech_read_config(&config_buffer, test_ref_file);
        if (ret != 0) {
            DBG_PRINTF("Cannot read reference for <%s> from <%s>, err: %d (0x%x)", ref_file_name, test_ref_file, ret, ret);
        }
        else {
            if (config_buffer.off != config_len ||
                memcmp(config_buffer.base, config, config_len) != 0) {
                DBG_PRINTF("Data does not match reference for <%s> from <%s>, len = %zu vs %zu",
                    ref_file_name, test_ref_file, config_len, config_buffer.off);
                ret = -1;
            }
        }
        ptls_buffer_dispose(&config_buffer);
    }
    return ret;
}

int ech_config_test(void)
{
    int ret = 0;
    char test_server_pub_key_file[512];
    const char* public_name = "test.example.com";
    uint8_t* config = NULL;
    size_t config_len = 0;

    if (picoquic_hpke_kems[0] == NULL) {
        picoquic_tls_api_init();
    }

    ret = picoquic_get_input_path(test_server_pub_key_file, sizeof(test_server_pub_key_file), picoquic_solution_dir,
        PICOQUIC_TEST_ECH_PUB_KEY);
    if (ret != 0) {
        DBG_PRINTF("Cannot find pub_key file in <%s>, err: %d (0x%x)", picoquic_solution_dir, ret, ret);
    }
    else if ((ret = picoquic_ech_create_config_from_public_key(&config, &config_len, test_server_pub_key_file, public_name)) != 0) {
        DBG_PRINTF("Cannot create ECH record from <%s>, err: %d (0x%x)", test_server_pub_key_file, ret, ret);
    }
    /* Save a config representation in ech_config.txt */
    if (ret == 0) {
        ret = picoquic_ech_save_config(config, config_len, ECH_CONFIG_FILE_TXT);
        if (ret == 0) {
            ret = ech_test_check_buf(config, config_len, PICOQUIC_TEST_ECH_CONFIG_REF);
        }
    }

    if (config != NULL) {
        free(config);
    }

    return ret;
}

int ech_config_p_test(void)
{
    int ret = 0;
    char test_server_key_file[512];
    const char* public_name = "test.example.com";
    uint8_t* config = NULL;
    size_t config_len = 0;

    if (picoquic_hpke_kems[0] == NULL) {
        picoquic_tls_api_init();
    }

    ret = picoquic_get_input_path(test_server_key_file, sizeof(test_server_key_file), picoquic_solution_dir,
        PICOQUIC_TEST_ECH_PRIVATE_KEY);
    if (ret != 0) {
        DBG_PRINTF("Cannot locate %s", PICOQUIC_TEST_ECH_PRIVATE_KEY);
    }
    else if ((ret = picoquic_ech_create_config_from_private_key(&config, &config_len, test_server_key_file, public_name)) != 0) {
        DBG_PRINTF("Cannot create ECH record from <%s>, err: %d (0x%x)", test_server_key_file, ret, ret);
    }

    /* Save a config representation in ech_config.txt */
    if (ret == 0) {
        ret = picoquic_ech_save_config(config, config_len, ECH_CONFIG_FILE_TXT);
        if (ret == 0) {
            ret = ech_test_check_buf(config, config_len, PICOQUIC_TEST_ECH_CONFIG_REF);
        }
    }

    if (config != NULL) {
        free(config);
    }

    return ret;
}

#if 0
/* ECH test of config from CERT */
int ech_cert_test(void)
{
    int ret = 0;
    char test_server_cert_file[512];
    uint8_t* config = NULL;
    size_t config_len = 0;

    if (picoquic_hpke_kems[0] == NULL) {
        picoquic_tls_api_init();
    }
    if ((ret = picoquic_get_input_path(test_server_cert_file, sizeof(test_server_cert_file), picoquic_solution_dir,
        PICOQUIC_TEST_ECH_CERT)) != 0) {
        DBG_PRINTF("Cannot find cert file in <%s>, err: %d (0x%x)", picoquic_solution_dir, ret, ret);
    }
    else if ((ret = picoquic_ech_create_config_from_cert(&config, &config_len, test_server_cert_file, "test.example.com")) != 0) {
        DBG_PRINTF("Cannot create config from cert file in <%s>, err: %d (0x%x)", test_server_cert_file, ret, ret);
    }
    else {
        ptls_iovec_t io_config = { .base = config, .len = config_len };
        ret = ech_test_check_buf(io_config, PICOQUIC_TEST_ECH_CONFIG_REF);
        free(config);
    }

    return ret;
}
#endif
/* ECH end to end test. Create a connection, verify that the proper files
* are returned.
 */

typedef struct st_ech_e2e_spec_t {
    int expect_success;
    int expect_grease;
    int no_ech_server;
    int complete_cnx;
    int try_twice;
} ech_e2e_spec_t;

int ech_test_check_retry_config(picoquic_cnx_t* cnx,
    uint8_t* config, size_t config_len)
{
    int ret = 0;
    uint8_t* retry_config;
    size_t retry_config_len;

    picoquic_ech_get_retry_config(cnx, &retry_config, &retry_config_len);

    if (retry_config == NULL ||
        retry_config_len != config_len ||
        memcmp(retry_config, config, config_len) != 0) {
        ret = -1;
    }
    return ret;
}

#define ECH_TICKET_FILE_NAME "ech_ticket_store.bin"

static test_api_stream_desc_t ech_scenario_small[] = {
    { 4, 0, 256, 1000 }
};

int ech_test_complete_cnx(picoquic_test_tls_api_ctx_t* test_ctx, uint64_t* loss_mask, uint64_t* simulated_time)
{
    /* load a small scenario */
    int ret = test_api_init_send_recv_scenario(test_ctx, ech_scenario_small, sizeof(ech_scenario_small));

    /* Perform a data sending loop */
    if (ret == 0) {
        ret = tls_api_data_sending_loop(test_ctx, loss_mask, simulated_time, 0);
    }

    /* Before closing, wait for the session ticket to arrive */
    ret = session_resume_wait_for_ticket(test_ctx, simulated_time);

    /* verify that the transmission was complete */
    if (ret == 0) {
        ret = tls_api_one_scenario_body_verify(test_ctx, simulated_time, 1000000);
    }

    /* Verify that the session ticket has been received correctly */
    if (ret == 0) {
        if (test_ctx->qclient->p_first_ticket == NULL) {
            DBG_PRINTF("%s", "no ticket received.");
            ret = -1;
        }
        else {
            ret = picoquic_save_tickets(test_ctx->qclient->p_first_ticket, *simulated_time, ECH_TICKET_FILE_NAME);
            if (ret != 0) {
                DBG_PRINTF("ticket save error (0x%x).\n", ret);
            }
        }
    }

    return ret;
}


int ech_e2e_second(picoquic_test_tls_api_ctx_t* test_ctx, ptls_buffer_t *ech_config_buf, uint64_t * loss_mask, uint64_t* simulated_time)
{
    int ret = 0;

    /* We should verify that 0RTT works for the 2nd connection */
    picoquic_delete_cnx(test_ctx->cnx_client);
    test_ctx->cnx_client = NULL;
    if (test_ctx->cnx_server != NULL) {
        picoquic_delete_cnx(test_ctx->cnx_server);
        test_ctx->cnx_server = NULL;
    }

    /* recreate the client connection */
    test_ctx->cnx_client = picoquic_create_cnx(test_ctx->qclient, picoquic_null_connection_id,
        picoquic_null_connection_id,
        (struct sockaddr*)&test_ctx->server_addr, *simulated_time,
        PICOQUIC_INTERNAL_TEST_VERSION_1, PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, 1);

    if (test_ctx->cnx_client == NULL) {
        ret = -1;
    }
    else {
        if (ech_config_buf->off > 0) {
            picoquic_ech_configure_client(test_ctx->cnx_client, ech_config_buf->base, ech_config_buf->off);
        }

        ret = picoquic_start_client_cnx(test_ctx->cnx_client);
    }

    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, loss_mask, 0, simulated_time);
    }
    if (ret == 0 ) {
        /* If resume succeeded, the second connection will have a type "PSK" */
        if (picoquic_tls_is_psk_handshake(test_ctx->cnx_client) == 0) {
            DBG_PRINTF("%s", "ECH test, second connection is not PSK.");
            ret = -1;
        }
        else {
            /* run a receive loop until no outstanding data */
            ret = tls_api_synch_to_empty_loop(test_ctx, simulated_time, 2048, 0, 0);
        }
    }
    return ret;
}

int ech_e2e_test_one(ech_e2e_spec_t* spec)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_connection_id_t initial_cid = { {0xec, 0x8e, 0x2e, 0, 0, 0, 0, 0}, 8 };
    ptls_buffer_t ech_config_buf = { 0 };
    char ech_test_key_file[512];
    char ech_test_config_file[512];
    int ret;

    initial_cid.id[3] = (uint8_t)spec->expect_success;
    initial_cid.id[4] = (uint8_t)spec->expect_grease;

    ptls_buffer_init(&ech_config_buf, "", 0);


    /* Initialize an empty ticket store */
    ret = picoquic_save_tickets(NULL, simulated_time, ECH_TICKET_FILE_NAME);

    /* Create a test context with delayed init */
    ret = tls_api_init_ctx_ex(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, ECH_TICKET_FILE_NAME, NULL, 0, 1, 0, &initial_cid);

    if (ret == 0) {
        ret = picoquic_get_input_path(ech_test_key_file, sizeof(ech_test_key_file), picoquic_solution_dir,
            PICOQUIC_TEST_ECH_PRIVATE_KEY);
        if (ret != 0) {
            DBG_PRINTF("Cannot locate %s", PICOQUIC_TEST_ECH_PRIVATE_KEY);
        }
    }
    if (ret == 0) {
        ret = picoquic_get_input_path(ech_test_config_file, sizeof(ech_test_config_file), picoquic_solution_dir,
            PICOQUIC_TEST_ECH_CONFIG);
        if (ret != 0) {
            DBG_PRINTF("Cannot locate %s", PICOQUIC_TEST_ECH_CONFIG);
        }
    }

    if (ret == 0) {
        /* server side configuration */
        picoquic_set_qlog(test_ctx->qserver, ".");
        test_ctx->qserver->use_long_log = 1;
        if (!spec->no_ech_server) {
            ret = picoquic_ech_configure_quic_ctx(test_ctx->qserver, ech_test_key_file, ech_test_config_file);
            if (ret != 0) {
                DBG_PRINTF("Cannot configure quic server context for ECH, ret = %d (0x%x).", ret, ret);
            }
        }
    }
    if (ret == 0 && (!spec->no_ech_server || spec->expect_grease)) {
        /* client side configuration */
        ret = picoquic_ech_configure_quic_ctx(test_ctx->qclient, NULL, NULL);
        if (ret != 0) {
            DBG_PRINTF("Cannot configure quic client context for ECH, ret = %d (0x%x).", ret, ret);
        }
    }

    if (!spec->no_ech_server) {
        if (ret == 0) {
            /* Read the ECH config from the same file used for the server */
            ret = picoquic_ech_read_config(&ech_config_buf, ech_test_config_file);
        }

        if (ret == 0) {
            if (spec->expect_success) {
                ret = picoquic_ech_configure_client(test_ctx->cnx_client, ech_config_buf.base, ech_config_buf.off);
            }
            else if (spec->expect_grease) {
                ret = picoquic_ech_configure_client(test_ctx->cnx_client, NULL, 0);
            }
            else {
                ret = -1;
            }
            if (ret != 0) {
                DBG_PRINTF("Cannot configure quic client connection for ECH, ret = %d (0x%x).", ret, ret);
            }
        }
    }

    if (ret == 0) {
        /* start the client connection, thus creating a TLS context */
        ret = picoquic_start_client_cnx(test_ctx->cnx_client);
    }

    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 0, &simulated_time);
    }

    if (ret == 0 && (!TEST_CLIENT_READY || !TEST_SERVER_READY)) {
        DBG_PRINTF("%s", "Connection failed!");
        ret = -1;
    }

    if (ret == 0) {
        if (spec->expect_success) {
            /* TODO: verify that ECH worked! */
            if (!picoquic_is_ech_handshake(test_ctx->cnx_client)) {
                DBG_PRINTF("%s", "ECH negotiation failed!");
                ret = -1;
            }
        }
        else if (picoquic_is_ech_handshake(test_ctx->cnx_client)) {
            DBG_PRINTF("%s", "ECH negotiation should have failed!");
            ret = -1;
        }
        else if (ech_test_check_retry_config(test_ctx->cnx_client,
            ech_config_buf.base, ech_config_buf.off) != 0) {
            if (!spec->no_ech_server) {
                /* TODO: understand why this does not work. */
                DBG_PRINTF("%s", "No retry config available!");
            }
        }
        else if (spec->no_ech_server) {
            DBG_PRINTF("%s", "There should be no retry config!");
            ret = -1;
        }
    }

    if (ret == 0 && spec->complete_cnx) {
        ret = ech_test_complete_cnx(test_ctx, &loss_mask, &simulated_time);
    }

    if (ret == 0 && spec->try_twice) {
        ret = ech_e2e_second(test_ctx, &ech_config_buf, &loss_mask, &simulated_time);
    }

    ptls_buffer_dispose(&ech_config_buf);

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
        test_ctx = NULL;
    }

    return ret;
}

int ech_e2e_test(void)
{
    ech_e2e_spec_t spec = { 0 };
    spec.expect_success = 1;
    return ech_e2e_test_one(&spec);
}

int ech_e2e_0rtt_test(void)
{
    ech_e2e_spec_t spec = { 0 };
    spec.expect_grease = 1;
    spec.complete_cnx = 1;
    spec.try_twice = 1;
    return ech_e2e_test_one(&spec);
}

int ech_grease_test(void)
{
    ech_e2e_spec_t spec = { 0 };
    spec.expect_grease = 1;
    return ech_e2e_test_one(&spec);
}

int ech_no_ech_test(void)
{
    ech_e2e_spec_t spec = { 0 };
    spec.expect_grease = 0;
    spec.no_ech_server = 1;
    spec.complete_cnx = 1;
    spec.try_twice = 1;
    return ech_e2e_test_one(&spec);
}
